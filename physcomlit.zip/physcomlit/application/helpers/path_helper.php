<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('path_bas'))
{
    function path_()
    {
        $file_path = "/home/u1566964/public_html/physcomlit/assets/images/";
        return $file_path;
    }
}