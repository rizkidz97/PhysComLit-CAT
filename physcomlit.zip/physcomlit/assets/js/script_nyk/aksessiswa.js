/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
var table;

function check() {
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    $.post(base_url + "dash/Siswa/validusername", {
        CSRFToken: xData,
        username: $("#nis").val(),
        id: $("#savemethod").val()
    }, function(a) {
        1 == a ? $("#errorcheck").html("<div style='opacity: 0.87; position: absolute; top: 0px; left: 197px; margin-top: -34px;' class='usernameformError parentFormOwner formError ajaxed'><div class='formErrorContent'>* Username sudah dipakai</div><div class='formErrorArrow'><div class='line10'>\x3c!-- --\x3e</div><div class='line9'>\x3c!-- --\x3e</div><div class='line8'>\x3c!-- --\x3e</div><div class='line7'>\x3c!-- --\x3e</div><div class='line6'>\x3c!-- --\x3e</div><div class='line5'>\x3c!-- --\x3e</div><div class='line4'>\x3c!-- --\x3e</div><div class='line3'>\x3c!-- --\x3e</div><div class='line2'>\x3c!-- --\x3e</div><div class='line1'>\x3c!-- --\x3e</div></div></div>") : $("#errorcheck").html("")
    })
}

function checkCheckbox() {
    var countChk = $("#Guru input[name='kelas[]']:checked").length;
    if(countChk > 0) {$('#errorCheckbox').html('')}
    else {
    $('#errorCheckbox').html('<div class="A1formError parentFormRegs formError" style="opacity: 0.87; pointer-events: none; position: absolute; top: 1rem; left: 50px; margin-top: -30px;"><div class="formErrorContent">* Pilih salah satu kelas</div></div>');
    }
}

function readURL(a) {
    if (a.files && a.files[0]) {
        var e = new FileReader;
        e.onload = function(a) {
            $("#wizardPicturePreview").attr("src", a.target.result).fadeIn("slow")
        }, e.readAsDataURL(a.files[0])
    }
}

function edit_siswa(e) {
    $.ajax({
    type: "GET",
    data: {id:e},
    url: base_url + "dash/Siswa/ajaxedit",
    success: function(a) {
        var ciContact = a.kelas.split(",");
        for (var i = 0, len = ciContact.length; i < len; i++) {
          var exkls = ciContact[i].split('-');
          $('#'+exkls[1]).prop("checked", true);
        }
        $("html, body").animate({
        scrollTop: 0
        }, "slow"), $("#savemethod").val(e), $('[name="nis"]').val(a.username), $("#klsLama").val(a.kelas), $('[name="password"]').val(a.password), $('[name="passlama"]').val(a.password), $('[name="nama"]').val(a.nama), $("#nama_sekolah").val(a.idsekolah).change(), $('[name="telp"]').val(a.telp), $("#filepotodulu").val(a.poto), "" != a.poto ? $(".UpPoto").attr("src", base_url + "viewImageprofil/" + a.poto) : $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png"), $("#wizard-picture").attr("class", "");
    }
    });
}

function showsekolah() {
    $.getJSON(base_url + "dash/Siswa/ajaxsekolah", function(e) {
        $("#nama_sekolah").empty(), $.each(e, function(e, a) {
            $("#nama_sekolah").append($("<option></option>").val(a.idsekolah).html(a.nama_sekolah));
        }), $("#nama_sekolah").selectpicker("refresh");
    });
}

function reload_table() {
    table.ajax.reload(null, !1)
}

function clearForm() {
    $('[name="id"]').val(""), $('[name="filepotodulu"]').val(""), $('[name="psslama"]').val(""), $('[name="kelas"]').prop('checked', false)
}

function delete_siswa(a, f) {
    confirm("Yakin akan menghapus data ini?") && $.ajax({
        url: base_url + "dash/Siswa/ajaxdelete",
        type: "POST",
        data: {CSRFToken: csrf_table(), id: a, f: f},
        dataType: "JSON",
        success: function(a) {
            reload_table(), $("#Guru")[0].reset(), clearForm(), $("#nama_sekolah").selectpicker("refresh"), $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png"), $(".alertDel").hide().text('Data Siswa Berhasil Dihapus').show("slow").delay(3e3).hide("slow")
        },
        error: function(a, e, t) {
            alert("Error deleting data")
        }
    })
}

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}
 
$(document).ready(function() {
    showsekolah(), table = $("#table_data").DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },
        ajax: {
            url: base_url + "dash/Siswa/ajaxlist",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table()
                })
            }
        },
        columnDefs: [{
            targets: [0, 5, 6, 7],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 5, 6, 7]
        }, {
            className: "text-center",
            targets: [0, 2, 3, 4, 5, 6, 7]
        }, {
            className: "text-nowrap",
            targets: [0, 1]
        }]
    }), $("#wizard-picture").change(function() {
        readURL(this)
    }), $("form :checkbox").change(function () {
        checkCheckbox();
    }), $("#Guru").validationEngine(), $(".alert").hide(), $("#btnSave").click(function() {
        var a;
        check(), checkCheckbox();
        var e = $("#savemethod").val(),
            t = $("#Guru").validationEngine("validate");
        a = "" == e ? base_url + "dash/Siswa/ajaxadd" : base_url + "dash/Siswa/ajaxupdate";
        var s = $("#errorcheck").text(),
            r = $("#errorCheckbox").text();
        if (1 == t && "" == s && "" == r) {
            $("#btnSave").text("saving..."), $("#btnSave").attr("disabled", !0);
            var strMD5 = $().crypt({
                method: "md5",
                source: $('#passW').val()
            });
            var n = new FormData($("#Guru")[0]);
            var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
            n.append("CSRFToken", xData), n.append("pass", strMD5), n.append("passx", $('#passW').val()), $.ajax({
                url: a,
                type: "POST",
                data: n,
                contentType: !1,
                cache: !1,
                processData: !1,
                dataType: "JSON",
                success: function(a) {
                    1 == a.status && (reload_table(), $("#Guru")[0].reset(), clearForm(), $("#nama_sekolah").selectpicker("refresh"), $(".is_datakelas").empty(), $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png"), $(".alertSuc").hide().text('Data Siswa Berhasil Disimpan').show("slow").delay(3e3).hide("slow")), $("#btnSave").text("SIMPAN"), $("#btnSave").attr("disabled", !1)
                }
            })
        } else $("#Guru").validationEngine()
    }), $(".tableGuru tbody").on("change", "input[type=checkbox]", function() {
        var xDatax = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var a = $(this).val(),
            e = $(this).attr("name"),
            t = ($(this).attr("id"), $(this).parent().prev().attr("class"), {
                CSRFToken: xDatax,
                idni: e,
                valni: a
            });
        $.ajax({
            type: "POST",
            url: base_url + "dash/Siswa/ajaxonoff",
            data: t,
            cache: !1,
            dataType: "JSON",
            success: function(a) {
                reload_table()
            }
        })
    }), $('#Guru').keypress(function(d) {
        13 == d.which && $('#btnSave').click()
    }), $("#nama_sekolah").on('change', function() {
        $('.btn.dropdown-toggle.btn-default').attr('data-original-title', $("#nama_sekolah option:selected" ).text());
        $.getJSON(base_url + "dash/Siswa/ajaxKelas", {skl: $("#nama_sekolah option:selected" ).val()}).done(function(e) {
        $(".is_datakelas").empty(), $.each(e, function(e, a) {
        $(".is_datakelas").append('<input type="radio" value="'+a.kls+'" name="kelas[]" id="'+$("#nama_sekolah option:selected" ).val()+'_'+a.kls+'" class="ckelasc"><label for="'+$("#nama_sekolah option:selected" ).val()+'_'+a.kls+'"><span><span></span></span>Kelas: '+a.kls+'</label>');
        });
        if ($('#klsLama').val() != "") {
            $("#"+$("#nama_sekolah option:selected" ).val()+"_"+$('#klsLama').val()).prop("checked", true);
        }
        $(".ckelasc").change(function() {
            if(this.checked) {
                $('#errorCheckbox').html('');
            } else {
                $('#errorCheckbox').html('<div class="A1formError parentFormRegs formError" style="opacity: 0.87; pointer-events: none; position: absolute; top: 1rem; left: 50px; margin-top: -30px;"><div class="formErrorContent">* Pilih salah satu kelas</div></div>');
            }
        });
        });
    })
});