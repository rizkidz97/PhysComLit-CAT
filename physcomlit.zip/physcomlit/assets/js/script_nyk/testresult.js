/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});

var table, table2;

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}

function reload_table(id, nis, tgl) {
  $('#table_datasoal').DataTable().clear().destroy();
    createTable(id, nis, tgl);
    table.ajax.reload(null,false); 
}

function viewFunction(id, nis, tgl) {
    $('#resultAwal').hide('slow');
    $('#h_poin').show('slow');
    reload_table(id, nis, tgl);
    datasiswa(id, nis, tgl);
}

function datasiswa(id, nis, tgl) {
    $.getJSON(base_url + 'dash/Laporan/datasiswa', {id: id, nis: nis, tgl: tgl}).done(function(data) {
        $("#namaSiswa").text(data.nama);
        $("#sekolahSiswa").text(data.sekolah);
        $("#kelasSiswa").text(data.kelas);
        $("#guruTest").text(data.guru);
        $("#waktuTest").text(data.waktu);
        $("#nilai").text(data.skor);
        $("#ketPoin").text(data.ketPoin);
    });
}

function createTable(id, nis, tgl) {
    table = $('#table_datasoal').DataTable({
        paging:false,
        ordering:false,
        info: false,
        filter: false,
        retrieve:true,
        processing: true,
        serverSide: true,
        order: [],
        ajax: {
            url: base_url + "front/Test/list_hasilsiswa",
            type: "POST",
            data: function (d) {
                return $.extend({}, d, {
                "CSRFToken": csrf_table(),
                "idmode": id,
                "nis": nis,
                "tgl": tgl,
            });
            }
        },
        columnDefs: [{
            targets: [0, 1, 2, 3],
            orderable: !1
        }, {
            width: "3%",
            targets: [0]
        }, {
            width: "5%",
            targets: [2, 3]
        }, {
            className: "text-center",
            targets: [0, 2, 3]
        }, {
            className: "text-nowrap",
            targets: [0, 2, 3]
        }],
        fixedColumns: true
    });
}

function printdiv(printpage) {
var contents = $("#dvContents").html();
        var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" });
        $("body").append(frame1);
        var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
        //Create a new HTML document.
        frameDoc.document.write('<html><head><title>Rekap Laporan Test</title>');
        frameDoc.document.write('</head><body>');
        //Append the external CSS file.
        frameDoc.document.write('<link href="'+base_url+'assets/front/css/theme.css" rel="stylesheet" type="text/css" />');
        //Append the DIV contents.
        frameDoc.document.write(contents);
        frameDoc.document.write('</body></html>');
        frameDoc.document.close();
        setTimeout(function () {
            window.frames["frame1"].focus();
            window.frames["frame1"].print();
            frame1.remove();
        }, 500);
}

$(document).ready(function() {
    $('#mainNav .nav-item a').removeClass('active');
    $('#mainNav .nav-item a#pitu').addClass('active');
    table = $('#table_dataawal').DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },
        ajax: {
            url: base_url + "front/Testresult/ajaxlist",
            type: "POST",
            data: function (d) {
                return $.extend({}, d, {
                "CSRFToken": csrf_table()
            });
            }
        },
        columnDefs: [
        {"targets": [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ], "orderable": false},
        {className: "text-center", "targets": [0, 1, 2, 3, 4, 5, 6, 7, 8]},
        {width: "3%", targets: [0, 8]},
        {className: "text-nowrap", "targets": [0, 1]},
        ],
    });
});