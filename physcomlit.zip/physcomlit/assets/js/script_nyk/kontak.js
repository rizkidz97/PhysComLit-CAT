/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
var table;

function reload_table() {
    table.ajax.reload(null, !0)
}

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}

function del_funcion(id) {
    confirm("Yakin akan menghapus data ini?") && $.ajax({
        url: base_url + "dash/Kontak/ajaxdelete",
        type: "POST",
        data: {CSRFToken: csrf_table(), id: id},
        dataType: "JSON",
        success: function(a) {
            reload_table(), $(".alertDel").hide().text('Data Kontak Berhasil Dihapus').show("slow").delay(3e3).hide("slow")
        },
        error: function(a, e, t) {
            alert("Error deleting data")
        }
    })
}

function balas_pesan(id) {
    $.getJSON( base_url +'dash/Kontak/ajaxbalas', {id: id}).done(function(data) {
        $('.k_1').hide('slow');
        $('.k_2').show('slow');
        $('#savemethod').val(id);
        $('#u_email').val(data.email_user);
        $('#u_nama').val(data.nama_user);
        $('#u_tanggal').val(data.tanggal);
        $('#u_judul').val(data.judul_pesan);
        $('#u_pesan').val(data.pesan);

        $('#nama_pengirim').text(data.nama_user);
        $('#email_pengirim').text(data.email_user);
        $('#tanggal_pengirim').text(data.tanggal);
        $('#judul').text(data.judul_pesan);
        $('#pesan').text(data.pesan);
        
        if(data.balasan != "" || data.balasan != null) {
            $('#act').val(data.balasan);
            $('#my_balasanpesan').html(data.balasan);
            tinyMCE.get('my_balasanpesan').setContent(data.balasan);
        } else {
            $('#act').val("");
        }
    });
}

tinymce.init({
    selector: "textarea",theme: "modern",width: '100%',height: 200,
    menubar:false,
    statusbar: false,
    plugins: [
         "eqneditor advlist autolink link image lists charmap print preview hr anchor pagebreak",
         "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking",
         "table contextmenu directionality emoticons paste textcolor responsivefilemanager code"
   ],
   setup: function (editor) {
        editor.on('change', function () {
            editor.save();
        });
    },
   toolbar1: "bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist | subscript superscript | eqneditor responsivefilemanager image | preview code",
   image_advtab: true ,
   relative_urls:false,
   external_filemanager_path:base_url+"assets/filemanager/",
   filemanager_title:"Responsive Filemanager" ,
   external_plugins: { "filemanager" : base_url+"assets/filemanager/plugin.min.js"}
 });

$(document).ready(function() {
    table = $("#table_data").DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },
        ajax: {
            url: base_url + "dash/Kontak/ajaxlist",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table()
                })
            }
        },
        columnDefs: [{
            targets: [0, 5, 6, 7],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 6, 7]
        }, {
            width: "10%",
            targets: [1, 2, 5]
        }, {
            className: "text-center",
            targets: [0, 5, 6, 7]
        }, {
            className: "text-nowrap",
            targets: [0, 1]
        }]
    }), $("#btnKrmBalasan").click(function () {
        tinyMCE.triggerSave();
        var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var dt = new FormData($("#Kontakpesan")[0]);
        dt.append("CSRFToken", xData);
        if($('#my_balasanpesan').val() != "") {
        $.ajax({
            url : base_url +'dash/Kontak/ajaxupdate',
            type: "POST",
            data: dt,
            contentType: !1,
            cache: !1,
            processData: !1,
            dataType: "JSON",
            success: function(data)
            {
                if(data.status) {
                    reload_table();
                    $('.k_2').hide('slow');
                    $('.k_1').show('slow');
                    $('#savemethod').val("");
                    $('#act').val("");
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                    $(".alertSuc").hide().show('slow').delay(3000).hide('slow');
            }
                $('#btnSaveSoal').text('Save Soal');
                $('#btnSaveSoal').attr('disabled',false);
     
            },
        
        });
        }
    })
});