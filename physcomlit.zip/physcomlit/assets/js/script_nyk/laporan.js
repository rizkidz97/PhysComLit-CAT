/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
var table, table1;

function reload_table() {
    table.ajax.reload(null, !0)
}

function reload_table_del() {
    table.ajax.reload(null, !1)
}

function reload_table1() {
    createTable();
    table1.columns.adjust().draw();
}


function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}

function del_funcion(nis, tgl) {
    confirm("Yakin akan menghapus data ini?") && $.ajax({
        url: base_url + "dash/Laporan/ajaxdelete",
        type: "POST",
        data: {CSRFToken: csrf_table(), nis: nis, tgl: tgl},
        dataType: "JSON",
        success: function(a) {
            reload_table_del(), $(".alertDel").hide().text('Data Hasil Poin Siswa Berhasil Dihapus').show("slow").delay(3e3).hide("slow")
        },
        error: function(a, e, t) {
            alert("Error deleting data")
        }
    })
}

function view_funcion(idmode, nis, tgl, poto, nama) {
    $('.TableLaporan').hide();
    $('.TableLaporanDetail1').show();
    $('#idmodex').val(idmode);
    $('#nisx').val(nis);
    $('#tglx').val(tgl);
    $('#nm_S').val(nama)
    var pto;
        if (poto == "") {pto = "default-avatar.png"} else {pto = poto}
        $('.proimg').attr('src', base_url+'viewImageprofil/'+pto);
    reload_table1();
    datasiswa(idmode, nis, tgl);
}

function datasiswa(idmode, nis, tgl) {
    $.getJSON(base_url + 'dash/Laporan/datasiswa', {id: idmode, nis: nis, tgl: tgl}).done(function(data) {
        $("#namaSiswa").text(data.nama);
        $("#sekolahSiswa").text(data.sekolah);
        $("#judulSiswa").text(data.judul_test);
        $("#kelasSiswa").text(data.kelas);
        $("#guruTest").text(data.guru);
        $("#waktuTest").text(data.waktu);
        $("#theta_akr").text(data.theta_akr);
        $("#nilai").text(data.skor);
        $("#ketPoin").text(data.ketPoin);
    });
}

function createTable() {
    table1 = $('#table_datadetail').DataTable({
        "dom": 'fBrtip<"clear">l',
        "paging":   false,
        "ordering": false,
        "info":     false,
        "filter": false,
        "retrieve": true,
        "processing": true,
        "serverSide": true,
        "order": [],
          "ajax": {
            "url": base_url + "dash/Laporan/list_hasilsiswa",
            "type": "POST",
            "data": function (d) {
                return $.extend({}, d, {
                "CSRFToken": csrf_table(),
                "idmode": $('#idmodex').val(),
                "nis": $('#nisx').val(),
                "tgl": $('#tglx').val()
            });
            }
        },
    columnDefs: [
        {targets: [ -1 ], "orderable": false},
        {className: "text-center", "targets": [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]},
        {className: "text-nowrap", "targets": [0,1]},
        ], buttons: [{
            extend: "excelHtml5",
            title: "Laporan Data CAT "+$('#nm_S').val(),
            className: "_excel",
            orientation: "landscape",
            columns: ":visible",
            exportOptions: {
                columns: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]
            }
        }, {
            extend: "pdfHtml5",
            title: "Laporan Data CAT "+$('#nm_S').val(),
            message: "",
            className: "_pdf",
            orientation: "landscape",
            pageSize: "A4",
            exportOptions: {
                columns: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]
            },
            customize: function(q) {
                var z = new Date,
                    B = z.getDate() + "-" + (z.getMonth() + 1) + "-" + z.getFullYear();
                q.pageMargins = [30, 50, 30, 50], q.defaultStyle.fontSize = 10, q.styles.tableHeader.fontSize = 10, q.styles.title.fontSize = 16, q.styles.tableFooter.fontSize = 10, q.defaultStyle.alignment  = 'center', q.content[0].text = q.content[0].text.trim(), q.content[1].table.widths = [ '3%',  '8%', '3%', '5%', '5%', '5%', '5%', '3%', '4%', '5%', '5%', '6%', '6%', '6%', '6%', '4%', '4%', '4%', '5%', '8%'], q.footer = function(F, G) {
                    return {
                        columns: [{
                            alignment: "left",
                            text: ["Created on: ", {
                                text: B.toString()
                            }]
                        }, {
                            alignment: "right",
                            text: ["page ", {
                                text: F.toString()
                            }, " of ", {
                                text: G.toString()
                            }]
                        }],
                        margin: [50, 0]
                    }
                }, q.content[1].layout = {
                    hLineWidth: function() {
                        return .5
                    },
                    vLineWidth: function() {
                        return .5
                    },
                    hLineColor: function() {
                        return "#aaa"
                    },
                    vLineColor: function() {
                        return "#aaa"
                    },
                    paddingLeft: function() {
                        return 4
                    },
                    paddingRight: function() {
                        return 4
                    }
                }
            }
        }],
        initComplete: function() {
            var a = $(".dt-buttons").hide();
            $("#exportLinkUtama2").on("change", function() {
                var e = $(this).find(":selected")[0].id ? "._" + $(this).find(":selected")[0].id : null;
                e && a.find(e).click()
            })
        }
    });
}

function get_kelas() {
    $.getJSON(base_url + "dash/Laporan/ajaxKelas", {skl: $("#sekolah option:selected" ).val()}).done(function(e) {
        $("#kelas").empty(), $("#kelas").append($("<option></option>").val('').html('--Pilih Kelas--')), $.each(e, function(e, a) {
         $("#kelas").append($("<option></option>").val(a).html("Kelas "+a));
        });
    });
}

$(document).ready(function() {
    $.getJSON(base_url + "dash/Laporan/ajaxsekolah", function(e) {
        $('#sekolah').empty();
        $("#sekolah").append($("<option></option>").val('').html('--Pilih Sekolah--'));
        $.each(e, function(i, d) {
            $("#sekolah").append($("<option></option>").val(d.idsekolah).html(d.nama_sekolah));
        })
        $("#sekolah").val($("#sekolah").find('option').first().val());
    });
    table = $("#table_data").DataTable({
        dom: 'fBrtip<"clear">l',
        responsive: !0,
        processing: !0,
        serverSide: !0,
        filter: !1,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },
        ajax: {
            url: base_url + "dash/Laporan/ajaxlist",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table(),
                    idsekolah: $('#sekolah').val(),
                    kelas: $('#kelas').val(),
                    sepok: $('#sepok').val(),
                    tgl_awl: $('#tgl_awl').val(),
                    tgl_ahr: $('#tgl_ahr').val(),
                })
            }
        },
        columnDefs: [{
            targets: [0, 10, 11],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 10, 11]
        }, {
            width: "6%",
            targets: [3, 5, 6, 7, 8, 9]
        }, {
            className: "text-center",
            targets: [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
        }, {
            className: "text-nowrap",
            targets: [0, 1]
        }], buttons: [{
            extend: "excelHtml5",
            title: "LAPORAN DATA CAT PHYSCOMLIT",
            className: "inovasi-excel",
            orientation: "landscape",
            columns: ":visible",
            init: function(dt, node, config) {
                $("#sekolah").change(function() {
                    if($("#sekolah option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text();
                    }
                });
                $("#kelas").change(function() {
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase();
                    }
                });
                $("#tgl_awl").on('changeDate', function(selected) {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } 
                    else if($("#sekolah option:selected").val() != "" && $("#kelas option:selected").val() == "" && $("#tgl_awl").val() != "" && $("#tgl_ahr") != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+" PERIODE "+B+" SAMPAI "+B2;
                    }
                });
                $("#tgl_ahr").on('changeDate', function(selected) {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT"+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } 
                    else if($("#sekolah option:selected").val() != "" && $("#kelas option:selected").val() == "" && $("#tgl_awl").val() != "" && $("#tgl_ahr") != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+" PERIODE "+B+" SAMPAI "+B2;
                    }
                });
            },
            exportOptions: {
                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            }
        }, {
            extend: "pdfHtml5",
            title: "LAPORAN DATA CAT PHYSCOMLIT",
            message: "",
            className: "inovasi-pdf",
            orientation: "landscape",
            pageSize: "A4",
            init: function(dt, node, config) {
                $("#sekolah").change(function() {
                    if($("#sekolah option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text();
                    }
                });
                $("#kelas").change(function() {
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase();
                    }
                });
                $("#tgl_awl").on('changeDate', function(selected) {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } 
                    else if($("#sekolah option:selected").val() != "" && $("#kelas option:selected").val() == "" && $("#tgl_awl").val() != "" && $("#tgl_ahr") != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+" PERIODE "+B+" SAMPAI "+B2;
                    }
                });
                $("#tgl_ahr").on('changeDate', function(selected) {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT"+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } 
                    else if($("#sekolah option:selected").val() != "" && $("#kelas option:selected").val() == "" && $("#tgl_awl").val() != "" && $("#tgl_ahr") != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+" PERIODE "+B+" SAMPAI "+B2;
                    }
                });
            },
            exportOptions: {
                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            },
            customize: function(q) {
                var z = new Date,
                    B = z.getDate() + "-" + (z.getMonth() + 1) + "-" + z.getFullYear();
                q.pageMargins = [30, 50, 30, 50], q.defaultStyle.fontSize = 10, q.styles.tableHeader.fontSize = 10, q.styles.tableFooter.fontSize = 10, q.styles.title.fontSize = 16, q.defaultStyle.alignment  = 'center', q.content[0].text = q.content[0].text.trim(), q.content[1].table.widths = [ '2%',  '18%', '15%', '5%', '14%', '9%', '6%', '6%', '5%', '13%', '7%'], q.footer = function(F, G) {
                    return {
                        columns: [{
                            alignment: "left",
                            text: ["Created on: ", {
                                text: B.toString()
                            }]
                        }, {
                            alignment: "right",
                            text: ["page ", {
                                text: F.toString()
                            }, " of ", {
                                text: G.toString()
                            }]
                        }],
                        margin: [50, 0]
                    }
                }, q.content[1].layout = {
                    hLineWidth: function() {
                        return .5
                    },
                    vLineWidth: function() {
                        return .5
                    },
                    hLineColor: function() {
                        return "#aaa"
                    },
                    vLineColor: function() {
                        return "#aaa"
                    },
                    paddingLeft: function() {
                        return 4
                    },
                    paddingRight: function() {
                        return 4
                    }
                }
            }
        }, {
            extend: "print",
            title: "LAPORAN DATA CAT PHYSCOMLIT",
            className: "inovasi-print",
            orientation: "landscape",
            init: function(dt, node, config) {
                $("#sekolah").change(function() {
                    if($("#sekolah option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text();
                    }
                });
                $("#kelas").change(function() {
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase();
                    }
                });
                $("#tgl_awl").on('changeDate', function(selected) {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } 
                    else if($("#sekolah option:selected").val() != "" && $("#kelas option:selected").val() == "" && $("#tgl_awl").val() != "" && $("#tgl_ahr") != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+" PERIODE "+B+" SAMPAI "+B2;
                    }
                });
                $("#tgl_ahr").on('changeDate', function(selected) {
                    var z = $("#tgl_awl").val().split('-');
                    var B = z[2] + "-" + z[1] + "-" + z[0];
                    var z2 = $("#tgl_ahr").val().split('-');
                    var B2 = z2[2] + "-" + z2[1] + "-" + z2[0];
                    if($("#kelas option:selected").val() != "" && $("#tgl_awl").val() != "" && $("#tgl_ahr").val() != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT"+$('#jns').val()+' '+$("#kelas option:selected" ).text().toUpperCase()+" PERIODE "+B+" SAMPAI "+B2;
                    } 
                    else if($("#sekolah option:selected").val() != "" && $("#kelas option:selected").val() == "" && $("#tgl_awl").val() != "" && $("#tgl_ahr") != "") {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+' '+$("#sekolah option:selected" ).text()+" PERIODE "+B+" SAMPAI "+B2;
                    } else {
                    config.title = "LAPORAN DATA CAT PHYSCOMLIT "+$('#jns').val()+" PERIODE "+B+" SAMPAI "+B2;
                    }
                });
            },
            exportOptions: {
                stripHtml: false,
                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        },
            customize: function(e) {
                $(e.document.body).find("table").addClass("compact").css("font-size", "10pt");
                for (var a = e.document.querySelectorAll('[media="screen'), t = 0; t < a.length; t++) a.item(t).media = "all"
            }
        }],
        initComplete: function() {
            var a = $(".dt-buttons").hide();
            $("#exportLinkUtama").on("change", function() {
                var e = $(this).find(":selected")[0].id ? ".inovasi-" + $(this).find(":selected")[0].id : null;
                e && a.find(e).click()
            })
        }
    }), $('#sekolah').on('change', function() {
        get_kelas();
        reload_table();
    }), $('#kelas').on('change', function() {
        reload_table();
    }), $(".rangedate").datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true,
    }), $("#tgl_awl").on('changeDate', function(selected) {
        var startDate = new Date(selected.date.valueOf());
        $("#tgl_ahr").datepicker('setStartDate', startDate);
        if($("#tgl_awl").val() > $("#tgl_ahr").val()){
          $("#tgl_ahr").val($("#tgl_awl").val());
          reload_table();
        }
    }), $("#tgl_awl").on('changeDate', function(selected) {
        reload_table();
    }), $("#tgl_ahr").on('changeDate', function(selected) {
        reload_table();
    }), $(".backAwl").on('click', function() {
        $('.TableLaporan').show();
        $('.TableLaporanDetail1').hide();
        $("html, body").animate({ scrollTop: 0 }, 1000);
    }), $('#sepok').on('input', function() {
        reload_table();
    })
});