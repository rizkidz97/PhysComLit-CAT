/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
var table;
function reload_table() {
    table.ajax.reload(null, !1)
}

function readURL(a) {
    if (a.files && a.files[0]) {
        var e = new FileReader;
        e.onload = function(a) {
            $("#wizardPicturePreview").attr("src", a.target.result).fadeIn("slow")
        }, e.readAsDataURL(a.files[0])
    }
}

function check() {
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    $.post(base_url + "dash/Sekolah/valid", {
        CSRFToken: xData,
        skl: $("#nama_sekolah").val(),
        id: $("#savemethod").val()
    }, function(a) {
        1 == a ? $("#errorcheck").html("<div style='opacity: 0.87; position: absolute; top: 0px; left: 197px; margin-top: -34px;pointer-events: none;' class='usernameformError parentFormOwner formError ajaxed'><div class='formErrorContent'>* Sekolah sudah ada!!!</div><div class='formErrorArrow'><div class='line10'>\x3c!-- --\x3e</div><div class='line9'>\x3c!-- --\x3e</div><div class='line8'>\x3c!-- --\x3e</div><div class='line7'>\x3c!-- --\x3e</div><div class='line6'>\x3c!-- --\x3e</div><div class='line5'>\x3c!-- --\x3e</div><div class='line4'>\x3c!-- --\x3e</div><div class='line3'>\x3c!-- --\x3e</div><div class='line2'>\x3c!-- --\x3e</div><div class='line1'>\x3c!-- --\x3e</div></div></div>") : $("#errorcheck").html("")
    })
}

function clearForm() {
    $('[name="id"]').val(""), $('[name="logolama"]').val(""), $('[name="klslama"]').val("");
}

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}

function editFunction(id) {
    $("html, body").animate({
        scrollTop: 0
        }, "slow");
    $.getJSON(base_url +'dash/Sekolah/ajaxedit', {id: id}).done(function(data) {
        $('#kelas').tagsinput('removeAll');
        $('#savemethod').val(id);
        $('#nama_sekolah').val(data.nama_sekolah);
        $('#kelas').tagsinput('add', data.kelas);
        $("#logolama").val(data.logo);
        "" != data.logo ? $(".UpPoto").attr("src", base_url + "viewImagelogo/" + data.logo) : $(".UpPoto").attr("src", base_url + "viewImagelogo/icon-logo.png"), $("#wizard-picture").attr("class", "")
    });
}

function delFunction(a, f) {
    confirm("Yakin akan menghapus data ini?") && $.ajax({
        url: base_url + "dash/Sekolah/ajaxdelete",
        type: "POST",
        data: {CSRFToken: csrf_table(), id: a, f: f},
        dataType: "JSON",
        success: function(a) {
            reload_table(), $("#Sekolah")[0].reset(), clearForm(), $('#kelas').tagsinput('removeAll'), $(".UpPoto").attr("src", base_url + "viewImagelogo/icon-logo.png"), $(".alertDel").hide().text('Data Sekolah Berhasil Dihapus').show("slow").delay(3e3).hide("slow")
        },
        error: function(a, e, t) {
            alert("Error deleting data")
        }
    })
}

$(document).ready(function() {
    table = $("#table_data").DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },
        ajax: {
            url: base_url + "dash/Sekolah/ajaxlist",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table()
                })
            }
        },
        columnDefs: [{
            targets: [0, 3, 4],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 3, 4]
        }, {
            className: "text-center",
            targets: [0, 3, 4]
        }, {
            className: "text-nowrap",
            targets: [0, 1]
        }]
    }), $("#Sekolah").validationEngine(), $(".alert").hide(), $("#btnSave").click(function() {
        var a;
        var e = $("#savemethod").val(),
            t = $("#Sekolah").validationEngine("validate");
            a = "" == e ? base_url + "dash/Sekolah/ajaxadd" : base_url + "dash/Sekolah/ajaxupdate";
        var s = $("#errorcheck").text();
        if (1 == t && "" == s) {
            $("#btnSave").text("saving..."), $("#btnSave").attr("disabled", !0);
            var n = new FormData($("#Sekolah")[0]);
            var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
            n.append("CSRFToken", xData), $.ajax({
                url: a,
                type: "POST",
                data: n,
                contentType: !1,
                cache: !1,
                processData: !1,
                dataType: "JSON",
                success: function(a) {
                    1 == a.status && (reload_table(), $("#savemethod").val(""), $("#Sekolah")[0].reset(), clearForm(), $('#kelas').tagsinput('removeAll'), $(".UpPoto").attr("src", base_url + "viewImagelogo/icon-logo.png"), $(".alertSuc").hide().text('Data Sekolah Berhasil Disimpan').show("slow").delay(3e3).hide("slow")), $("#btnSave").text("SIMPAN"), $("#btnSave").attr("disabled", !1)
                }
            })
        } else $("#Sekolah").validationEngine()
    }), $("#wizard-picture").change(function() {
        readURL(this)
    })
});