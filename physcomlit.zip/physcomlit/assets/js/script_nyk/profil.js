/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
function checkPass() {
    $("#passPr").val().match(/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/) ? $("#errorcheckPass").html("") : $("#errorcheckPass").html("<div style='opacity: 0.87; position: absolute; top: 0px; left: 197px; margin-top: -34px;' class='passWformError parentFormOwner formError ajaxed'><div class='formErrorContent'>* Password minimal 8 huruf<br>* setidaknya satu simbol<br>* satu huruf besar<br>* satu huruf kecil dan angka</div><div class='formErrorArrow'><div class='line10'><!-- --></div><div class='line9'><!-- --></div><div class='line8'><!-- --></div><div class='line7'><!-- --></div><div class='line6'><!-- --></div><div class='line5'><!-- --></div><div class='line4'><!-- --></div><div class='line3'><!-- --></div><div class='line2'><!-- --></div><div class='line1'><!-- --></div></div></div>")
}

function readURL(b) {
    if (b.files && b.files[0]) {
        var c = new FileReader;
        c.onload = function(d) {
            $("#wizardPicturePreview").attr("src", d.target.result).fadeIn("slow")
        }, c.readAsDataURL(b.files[0])
    }
}

$(document).ready(function() {
    $(".toggle-password").click(function() {
        $(this).toggleClass("fa-eye fa-eye-slash");
        var b = $("#passPr");
        "text" == b.attr("type") ? b.attr("type", "password") : b.attr("type", "text")
    }), $(".inji").mCustomScrollbar(), $("#wizard-picture").change(function() {
        readURL(this)
    }), $("#Profil").validationEngine("attach", {
        promptPosition: "topRight:-150",
        scroll: !1
    }), $("#Password").validationEngine("attach", {
        promptPosition: "topRight:-150",
        scroll: !1
    }), $.ajax({
        url: base_url + "dash/Profil/ajaxedit",
        type: "GET",
        data:{id:$("#xuid").val()},
        dataType: "JSON",
        success: function(b) {
            $("[name=\"nama\"]").val(b.nama), 
            $("[name=\"telp\"]").val(b.telp), 
            $("[name=\"filepotodulu\"]").val(b.poto), 
            $("#nama_nya").text(b.nama), 
            "" != b.telp ? ($("#telp_nya").text(b.telp)) : ($("#telp_nya").text("-")), 
            $("#sekolah_nya").text(b.nama_sekolah), 
            $("#kelas_nya").text(b.kls), 
            "" == b.poto ? ($("#poto_nya").attr("src", base_url + "viewImageprofil/default-avatar.png"), $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png")) : ($("#poto_nya").attr("src", base_url + "viewImageprofil/" + b.poto), $(".UpPoto").attr("src", base_url + "viewImageprofil/" + b.poto))
        },
        error: function() {
            alert("Error get data from ajax")
        }
    }), $("#saveProfil").click(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        if (1 == $("#Profil").validationEngine("validate")) {
            var b = new FormData($("#Profil")[0]);
            b.append("CSRFToken", c_save), $.ajax({
                url: base_url + "dash/Profil/ajaxupdate",
                type: "POST",
                data: b,
                contentType: !1,
                cache: !1,
                processData: !1,
                dataType: "JSON",
                success: function(c) {
                    c.status && location.reload()
                }
            })
        } else $("#Profil").validationEngine("attach", {
            promptPosition: "topRight:-150",
            scroll: !1
        })
    }), $("#savePassword").click(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var strMD5 = $().crypt({
                method: "md5",
                source: $('#passPr').val()
            });
        var b = $("#Password").validationEngine("validate"),
            c = $("#Password").serializeArray();
        c.push({
            name: "CSRFToken",
            value: c_save
        }), c.push({
            name: "saiPass",
            value: strMD5
        }), c.push({
            name: "khuaPass",
            value: $('#ulangi').val()
        }), 1 == b ? $.ajax({
            url: base_url + "dash/Profil/ajaxupdatepassword",
            type: "POST",
            data: c,
            dataType: "JSON",
            success: function(d) {
                d.status && ($("#Password")[0].reset(), $("#myModalPassword").modal("hide"), $("#alertSuc").hide().show("slow").delay(3e3).hide("slow"))
            }
        }) : $("#Password").validationEngine("attach", {
            promptPosition: "topRight:-150",
            scroll: !1
        })
    })
});