/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});

var table, timer2;

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}

function reload_table() {
  $('#table_data').DataTable().clear().destroy();
    createTable();
    table.ajax.reload(null,false); 
}

function showperaturan(id) {
  $('#idmode').val(id);
  $.getJSON(base_url + 'front/Test/ajax_peraturan_test', {id: id, ket: $('.ket').val()}).done(function(data) {
  if(data.jam == null || data.selisihSe == null) {
  $('#peraturanx').show('slow');
  $('#sudahmengerjakan').hide('slow');
  $('#tgl_mulai').text(data.tgl_awal);
  $('#tgl_akhir').text(data.tgl_akhir);
  $('#jam_mulai').text(data.jam_awal);
  $('#jam_akhir').text(data.jam_akhir);
  $('#waktu').text(data.durasi + " Menit");
  $('#klsmengikuti').text(data.klsdipilih)
  } else {
  var date1 = new Date(data.tgl+" "+$('.twaktu_awalanda').val());
  var date2 = new Date(data.tgl+" "+data.jam);
  var res = Math.abs(date1 - date2) / 1000;
  var minutesx = Math.floor(res / 60) % 60;
    if (parseFloat(data.selisihSe) <= 0.001 || parseInt(minutesx) >= parseInt(data.durasi) || data.soal == null) {
      $('#peraturanx').hide('slow');
      $('#sudahmengerjakan').show('slow');
    } else{
      $('#peraturanx').hide('slow');
      var no = parseInt(data.soal_in) + 1;
      var xxminute;
      var pengurangan_minute = parseInt(data.durasi) - 1;
      $(".no_x").text(no);
      if (minutesx <= 0) {xxminute = pengurangan_minute+":"+data.wkt} else {xxminute = parseInt(data.durasi) - parseInt(minutesx)}
      $('#waktu').text(xxminute);
      $('#idmode').val(data.idmode);
      $('.ket').val(data.jdb);
      $('.tanda').val(data.tanda);
      $('.order').val(data.order);
      $('#btnMulai').click();
    }
  }
});
}

function datasiswa() {
	$.getJSON(base_url + 'dash/Laporan/datasiswa', {id: $('#idmode').val(), nis: $('#nissiswa').val(), tgl: $('#tglSekarang').val()}).done(function(data) {
		$("#namaSiswa").text(data.nama);
      	$("#sekolahSiswa").text(data.sekolah);
      	$("#kelasSiswa").text(data.kelas);
      	$("#guruTest").text(data.guru);
      	$("#waktuTest").text(data.waktu);
        $("#nilai").text(data.skor);
      	$("#ketPoin").text(data.ketPoin);
	});
}

function get_soal() {
  var ket = $('.ket').val();
  var tnd = $('.tanda').val();
  var ord = $('.order').val();
  $.getJSON(base_url + 'front/Test/ajax_get_soal', {id: $('#idmode').val(), ket: ket, tnd: tnd, ord: ord}).done(function(data) {
    $('#soal_show').empty();
    $('#soal_jawab').empty();
    $('#soal_alasan').empty();
    $('.kd_x').text(data.kd);
    $('.idsoal').val(data.idsoal);
    $('#soal_show').append(data.soal);
    if(data.soal == "" || data.soal == null) {
      $('#myModalTest').modal('hide');
      $(".no_x").text('1');
      $('#listTest').hide();
      $("#peraturanx").hide('slow');
      $("#h_poin").show('slow');
      datasiswa();
      reload_table();
    }
    $.each(data.jwb, function(idx, obj) {
    $('#soal_jawab').append('<li style="margin-left: 1.5rem;"><input type="radio" value="'+obj.ketAbjad+'" name="jwb" class="validate[required] radiopilih" id="radiojawab'+idx+'" style="float: left;margin-top: .35rem;"> <label for="radiojawab'+idx+'" style="margin-left: 18px;display: block;">'+obj.jawaban+'</label></li>');
    });
    $('#soal_alasan').append('<p><b>Alasan:</b></p>');
    $.each(data.als, function(ix, obx) {
    $('#soal_alasan').append('<li style="margin-left: 1.5rem;"><input type="radio" value="'+obx.ketAbjad+'" name="als" class="validate[required] radiopilih" id="radioalasan'+ix+'" style="float: left;margin-top: .35rem;"> <label for="radioalasan'+ix+'" style="margin-left: 18px;display: block;">'+obx.alasan+'</label></li>');
    });
    $('.modal-body').mCustomScrollbar('scrollTo', 'top');
  });
}

function ajax_url_jawab() {
    Notify.confirm({
      title : ' Jawaban Anda',
      html : '<span>Jawaban: <b>'+$("input[name='jwb']:checked").val()+'</b></span><br><span>Alasan: <b>'+$("input[name='als']:checked").val()+'</b></span>',
    ok : function(){
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    var dt = new FormData($("#JawabSoal")[0]);
        dt.append("CSRFToken", xData);
    $.ajax({
        url : base_url + "front/Test/ajax_add",
        type: "POST",
        data: dt,
        contentType: !1,
        cache: !1,
        processData: !1,
        dataType: "JSON",
        success: function(data) {
          if(data.status) {
            $('.ket').val(data.b);
            $('.tanda').val(data.tanda);
            $('.order').val(data.order);
            $('.twaktu_awalanda').val(data.waktuAwal);
            $('.loader_s').hide();
            $('input[name="tkt"]').prop('checked', false);
            if(parseFloat(data.slshSe) <= 0.001) {
              $('#myModalTest').modal('hide');
              $(".no_x").text('1');
              $('#listTest').hide();
              $("#peraturanx").hide('slow');
              $("#h_poin").show('slow');
              datasiswa();
              reload_table();
            } else {
              get_soal();
              var no = parseInt($(".no_x").text()) + 1;
              $(".no_x").text(no);
              $("#se_sel").val(data.slshSe);
            }
        } else {
          $('.loader_s').hide();
          $('.alertCheck').hide().show('slow').html('Jawaban Gagal Disimpan, Ulangi Lagi... !!').delay(3000).hide('slow');
        }
        },
    })
    },
    cancel : function(){
      $('.loader_s').hide();
      $('#btnJawab').text('Jawab');
      $('#btnJawab').attr('disabled',false);
      return false;
    }
    });
}

function disableF5(e) { if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82 || (e.which || e.keyCode) == 13) e.preventDefault(); return false;};

function timedCount() {
  var interval = setInterval(function() {
  var timer = timer2.split(':');
  var minutes = parseInt(timer[0], 10);
  var seconds = parseInt(timer[1], 10);
  --seconds;
  minutes = (seconds < 0) ? --minutes : minutes;
  if (minutes == 0 && seconds == 00) {
  clearInterval(interval);
  $('#myModalTest').modal('hide');
  $(".no_x").text('1');
  $('#listTest').hide();
  $("#peraturanx").hide('slow');
  $("#h_poin").show('slow');
  datasiswa();
  reload_table();
  }
  if(minutes == 5 && seconds == 00) {$('.alertCheck').hide().show('slow').html('<strong>Waktu Anda Tinggal 5 Menit Lagi... !!</strong>').delay(3000).hide('slow');}
  seconds = (seconds < 0) ? 59 : seconds;
  seconds = (seconds < 10) ? '0' + seconds : seconds;
  $('.countdown').html(minutes + ':' + seconds);
  $('.wkt_kerja').val(minutes + ':' + seconds);
  timer2 = minutes + ':' + seconds;
}, 1000);
}

function createTable() {
	table = $('#table_data').DataTable({
        paging:false,
        ordering:false,
        info: false,
        filter: false,
        retrieve:true,
        processing: true,
        serverSide: true,
        order: [],
    	ajax: {
            url: base_url + "front/Test/list_hasilsiswa",
            type: "POST",
            data: function (d) {
                return $.extend({}, d, {
                "CSRFToken": csrf_table(),
                "idmode": $('#idmode').val(),
                "nis": $('#nissiswa').val(),
                "tgl": $('#tglSekarang').val(),
            });
            }
        },
        columnDefs: [{
            targets: [0, 1, 2, 3],
            orderable: !1
        }, {
            width: "3%",
            targets: [0]
        }, {
            width: "5%",
            targets: [2, 3]
        }, {
            className: "text-center",
            targets: [0, 2, 3]
        }, {
            className: "text-nowrap",
            targets: [0, 2, 3]
        }],
        fixedColumns: true
    });
}

function printdiv(printpage) {
var contents = $("#dvContents").html();
        var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" });
        $("body").append(frame1);
        var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
        //Create a new HTML document.
        frameDoc.document.write('<html><head><title>Rekap Laporan Test</title>');
        frameDoc.document.write('</head><body>');
        //Append the external CSS file.
        frameDoc.document.write('<link href="'+base_url+'assets/js/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" />');
        //Append the DIV contents.
        frameDoc.document.write(contents);
        frameDoc.document.write('</body></html>');
        frameDoc.document.close();
        setTimeout(function () {
            window.frames["frame1"].focus();
            window.frames["frame1"].print();
            frame1.remove();
        }, 500);
}

$(document).ready(function() {
    $('#mainNav .nav-item a').removeClass('active');
    $('#mainNav .nav-item a#enom').addClass('active');
	$(".modal-body").mCustomScrollbar({advanced:{updateOnContentResize: true}, setTop: 0});
	$.getJSON(base_url + 'front/Test/ajax_get_test', {idsklh: sklh, kls: kls}).done(function(data) {
	if (data.length > 0) {
      $('#listTest').show();
      $('#peraturanx').hide();
      $("#h_poin").hide();
      $('#sudahmengerjakan').hide();
	  $('#idmode').val('');
      $.each(data, function(idx, obj) {
        $('#listTest').append('<a href="javascript:void(0)" id="'+obj.idm+'" nm="'+obj.judul_test+'" class="listtestcat"><div class="alert_n '+obj.cls+'" role="alert">' +
        obj.judul_test+':<br>Pengajar <span style="font-size:20px;">&#8594;</span> '+obj.nama+
        '<br>Tanggal <span style="font-size:20px;">&#8594;</span> '+obj.tgl_awal+' Jam: '+obj.jam_awal+' <span style="font-size:20px;">&harr;</span> '+obj.tgl_akhir+' Jam: '+obj.jam_akhir+
        '<br>Durasi <span style="font-size:20px;">&#8594;</span> '+obj.durasi+' Menit'+
        '</div></a>')
      });
      $('.listtestcat').on('click', function() {
        $id = $(this).attr('id');
        $('#listTest').hide();
        $('#peraturanx').show('slow');
        $("#h_poin").hide();
        $('#sudahmengerjakan').hide();
        showperaturan($id)
      })
	} else {
      $('#listTest').hide();
      $('#peraturanx').hide();
      $("#h_poin").hide();
      $('#sudahmengerjakan').show();
	  $('#idmode').val('');
	}       
	});

	$('#btnMulai').on('click', function () {
	var exwaktu_x = $('#waktu').text().split(':');
  var exwaktu;
  if (exwaktu_x[1] != null) {exwaktu = $('#waktu').text()} else {exwaktu = $('#waktu').text()+":00"}
	$(document).on("keydown", disableF5);
	$(window).on('beforeunload', function(){return 'Are you sure you want to leave?';});
	timer2 = exwaktu;
	timedCount();
	get_soal();
	});

	$("#btnJawab").on('click', function () {
	var radioJwb= $("input[name='jwb']:checked").val();
	var radioAls = $("input[name='als']:checked").val();
	if(radioJwb && radioAls) {
	  $('.loader_s').show();
	  ajax_url_jawab();
	} else {
	  $('.alertCheck').hide().show('slow').html('Jawaban, Atau Alasan<br>Masih ada yang kosong... !!').delay(3000).hide('slow');
	}
	});
});

jQuery(document).mouseup(function(e) {
    var container = jQuery('.notify-wrapper.show');
    if (!container.is(e.target) && container.has(e.target).length === 0) {

    } else {
      $('.loader_s').hide();
    }
});