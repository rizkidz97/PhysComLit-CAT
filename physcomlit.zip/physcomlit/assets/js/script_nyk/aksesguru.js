/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
var table;

function check() {
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    var a = $("#username").val();
    $.post(base_url + "dash/Guru/validusername", {
        CSRFToken: xData,
        username: $("#nip").val(),
        id: $("#savemethod").val()
    }, function(a) {
        1 == a ? $("#errorcheck").html("<div style='opacity: 0.87; position: absolute; top: 0px; left: 197px; margin-top: -34px;pointer-events: none;' class='usernameformError parentFormOwner formError ajaxed'><div class='formErrorContent'>* Username sudah dipakai</div><div class='formErrorArrow'><div class='line10'>\x3c!-- --\x3e</div><div class='line9'>\x3c!-- --\x3e</div><div class='line8'>\x3c!-- --\x3e</div><div class='line7'>\x3c!-- --\x3e</div><div class='line6'>\x3c!-- --\x3e</div><div class='line5'>\x3c!-- --\x3e</div><div class='line4'>\x3c!-- --\x3e</div><div class='line3'>\x3c!-- --\x3e</div><div class='line2'>\x3c!-- --\x3e</div><div class='line1'>\x3c!-- --\x3e</div></div></div>") : $("#errorcheck").html("")
    })
}

function checkCheckbox() {
    var countChk = $("#Guru input[name='klsgurux[]']:checked").length;
    if(countChk > 0) {$('#errorCheckbox').html('')}
    else {
    $('#errorCheckbox').html('<div class="A1formError parentFormRegs formError" style="opacity: 0.87; pointer-events: none; position: absolute; top: 0px; left: 201.5px; margin-top: -30px;"><div class="formErrorContent">* Pilih salah satu kelas</div></div>');
    }
}

function readURL(a) {
    if (a.files && a.files[0]) {
        var e = new FileReader;
        e.onload = function(a) {
            $("#wizardPicturePreview").attr("src", a.target.result).fadeIn("slow")
        }, e.readAsDataURL(a.files[0])
    }
}

function edit_guru(e) {
    $.ajax({
    type: "GET",
    data: {id:e},
    url: base_url + "dash/Guru/ajaxedit",
    success: function(a) {
        $("#nama_sekolah").val(a.idsekolah).trigger('change');
        setTimeout(function(){        
        var ciContact = a.kelas.split(",");
        for (var i = 0, len = ciContact.length; i < len; i++) {
          $('#'+ciContact[i]+'guru').prop("checked", true);
          $('#'+ciContact[i]+'guru').parent('.divcheck').removeClass('disableCheck');
        }
        },300);
        $("html, body").animate({
        scrollTop: 0
        }, "slow"), $("#savemethod").val(e), $('[name="nip"]').val(a.nip), $('[name="password"]').val(a.password), $('[name="passlama"]').val(a.password), $('[name="nama"]').val(a.nama), $('[name="telp"]').val(a.telp), $("#filepotodulu").val(a.poto), "" != a.poto ? $(".UpPoto").attr("src", base_url + "viewImageprofil/" + a.poto) : $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png"), $("#wizard-picture").attr("class", "")
    }
    });
}

function showsekolah() {
    $.getJSON(base_url + "dash/Guru/ajaxsekolah", function(e) {
        $("#nama_sekolah").empty(), $.each(e, function(e, a) {
            $("#nama_sekolah").append($("<option></option>").val(a.idsekolah).html(a.nama_sekolah));
        }), $("#nama_sekolah").selectpicker("refresh");
    });
}

function showcekKelas(ids, arr) {
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    $.post(base_url + "dash/Guru/cekKelas", {CSRFToken: xData, skl: ids, kls_i: arr}).done(function(e) {
        $.each(e, function(i, d) {
            if ($.inArray(d, arr) >= 0) {
                $('.liakCheckbox #_'+d).removeClass('disableCheck');
            } else {
                $('.liakCheckbox #_'+d).addClass('disableCheck');
            }
        });
    });
}

function reload_table() {
    table.ajax.reload(null, !1)
}

function clearForm() {
    $('[name="id"]').val(""), $('[name="filepotodulu"]').val(""), $('[name="pssLama"]').val(""), $('[name="klsguru"]').prop('checked', false)
}

function delete_guru(a, f) {
    confirm("Yakin akan menghapus data ini?") && $.ajax({
        url: base_url + "dash/Guru/ajaxdelete",
        type: "POST",
        data: {CSRFToken: csrf_table(), id: a, f: f},
        dataType: "JSON",
        success: function(a) {
            reload_table(), $("#Guru")[0].reset(), clearForm(), $("#nama_sekolah").selectpicker("refresh"), $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png"), $(".alertDel").hide().text('Data Guru Berhasil Dihapus').show("slow").delay(3e3).hide("slow")
        },
        error: function(a, e, t) {
            alert("Error deleting data")
        }
    })
}

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}
 
$(document).ready(function() {
    showsekolah(), table = $("#table_data").DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },
        ajax: {
            url: base_url + "dash/Guru/ajaxlist",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table()
                })
            }
        },
        columnDefs: [{
            targets: [0, 5, 6, 7, 8],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 6, 7, 8]
        }, {
            width: "10%",
            targets: [1, 2, 3]
        }, {
            className: "text-center",
            targets: [0, 3, 6, 7, 8]
        }, {
            className: "text-nowrap",
            targets: [0, 1]
        }]
    }), $("#wizard-picture").change(function() {
        readURL(this)
    }), $("form :checkbox").change(function () {
        checkCheckbox();
    }), $("#Guru").validationEngine(), $(".alert").hide(), $("#btnSave").click(function() {
        var a;
        check(), checkCheckbox();
        var e = $("#savemethod").val(),
            t = $("#Guru").validationEngine("validate");
        a = "" == e ? base_url + "dash/Guru/ajaxadd" : base_url + "dash/Guru/ajaxupdate";
        var s = $("#errorcheck").text(),
            r = $("#errorCheckbox").text();
        if (1 == t && "" == s && "" == r) {
            $("#btnSave").text("saving..."), $("#btnSave").attr("disabled", !0);
            var strMD5 = $().crypt({
                method: "md5",
                source: $('#passW').val()
            });
            var n = new FormData($("#Guru")[0]);
            var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
            n.append("CSRFToken", xData), n.append("pass", strMD5), n.append("passx", $('#passW').val()), $.ajax({
                url: a,
                type: "POST",
                data: n,
                contentType: !1,
                cache: !1,
                processData: !1,
                dataType: "JSON",
                success: function(a) {
                    1 == a.status && (reload_table(), $("#Guru")[0].reset(), clearForm(), $('.liakCheckbox').hide(), $('.liakCheckbox .divcheck').addClass('disableCheck'), $("#nama_sekolah").selectpicker("refresh"), $(".UpPoto").attr("src", base_url + "viewImageprofil/default-avatar.png"), $(".alertSuc").hide().text('Data Guru Berhasil Disimpan').show("slow").delay(3e3).hide("slow")), $("#btnSave").text("SIMPAN"), $("#btnSave").attr("disabled", !1)
                }
            })
        } else $("#Guru").validationEngine()
    }), $(".tableGuru tbody").on("change", "input[type=checkbox]", function() {
        var xDatax = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var a = $(this).val(),
            e = $(this).attr("name"),
            t = ($(this).attr("id"), $(this).parent().prev().attr("class"), {
                CSRFToken: xDatax,
                idni: e,
                valni: a
            });
        $.ajax({
            type: "POST",
            url: base_url + "dash/Guru/ajaxonoff",
            data: t,
            cache: !1,
            dataType: "JSON",
            success: function(a) {
                reload_table()
            }
        })
    }), $('#Guru').keypress(function(d) {
        13 == d.which && $('#btnSave').click()
    }), $('#nama_sekolah').on('change', function() {
        $('.liakCheckbox').show();
        var ids = $(this).val();
        $.getJSON(base_url + "dash/Guru/showKelas", {skl: ids}).done(function(e) {
        $('.liakCheckbox').empty();
        var plh_kls = [];
        $.each(e, function(i, d) {
            $('.liakCheckbox').append('<div style="float: left;" id="_'+d+'" class="disableCheck divcheck">'+
            '<input type="checkbox" value="'+d+'" name="klsgurux[]" id="'+d+'guru" class="Checkbox">'+
            '<label for="'+d+'guru"><span><span></span></span>'+d+'</label>'+
            '</div>');
            plh_kls.push(d);
        });
        showcekKelas(ids, plh_kls);
        });
    })
});