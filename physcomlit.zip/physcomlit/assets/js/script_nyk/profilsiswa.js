/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});

$(document).ready(function() {
    $('#mainNav .nav-item a').removeClass('active');
    $('#mainNav .nav-item a#walu').addClass('active');
    $.getJSON(base_url +'front/Profilsiswa/viewProfil', {uid: uidprofil}).done(function(data) {
        $('#pro_nama').text(data.nama);
        $('#pro_kelas').text(data.kelas);
        $('#pro_sekolah').text(data.nama_sekolah);
        $('#pro_telp').text(data.telp);
        $('.namasiswa').val(data.nama);
        $('.telpsiswa').val(data.telp);
        $('#passlamax').val(data.password);
        $('#potolama').val(data.poto);
        var pto;
        if (data.poto == "") {pto = "default-avatar.png"} else {pto = data.poto}
        $('.proimg').attr('src', base_url+'viewImageprofil/'+pto);
    }), $('.btnEditprofil').on('click', function() {
        $('#profilEdit').show('slow');
        $('#passEdit').hide('slow');
        $('.btnEditprofil').hide('slow');
        $('.closeeditprofil').show('slow');
        $('.closeeditpass').hide('slow');
        $('.btnEditpassword').show('slow');
    }), $('.btnEditpassword').on('click', function() {
        $('#profilEdit').hide('slow');
        $('#passEdit').show('slow');
        $('.btnEditpassword').hide('slow');
        $('.closeeditpass').show('slow');
        $('.closeeditprofil').hide('slow');
        $('.btnEditprofil').show('slow');
    }), $('.namasiswa').focusout(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var b = new FormData();
            b.append("CSRFToken", c_save),
            b.append("title", "nama"),
            b.append("xxx", $('.namasiswa').val());
        if($('.namasiswa').val() != "") {
        $('.namasiswa').css('border', '1px solid #7E92B2');
        $.ajax({
            url: base_url + "front/Profilsiswa/ajaxupdate",
            type: "POST",
            data: b,
            contentType: !1,
            cache: !1,
            processData: !1,
            dataType: "JSON",
            success: function(c) {
                c.status && $('#pro_nama').text($('.namasiswa').val());
            }
        })
        } else {
            $('.namasiswa').css('border', '1px solid red');
        }
    }), $('.telpsiswa').focusout(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var b = new FormData();
            b.append("CSRFToken", c_save),
            b.append("title", "telp"),
            b.append("xxx", $('.telpsiswa').val());
        $.ajax({
            url: base_url + "front/Profilsiswa/ajaxupdate",
            type: "POST",
            data: b,
            contentType: !1,
            cache: !1,
            processData: !1,
            dataType: "JSON",
            success: function(c) {
                c.status && $('#pro_telp').text($('.telpsiswa').val());
            }
        })
    }), $('.closeeditprofil').on('click', function() {
        $('#profilEdit').hide('slow');
        $('.closeeditprofil').hide('slow');
        $('.btnEditprofil').show('slow');
    }), $('.closeeditpass').on('click', function() {
        $('#passEdit').hide('slow');
        $('.closeeditpass').hide('slow');
        $('.btnEditpassword').show('slow');
    }), $('.passlama').focusout(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var strMD5 = $().crypt({
            method: "md5",
            source: $('.passlama').val()
        });
        var b = new FormData();
            b.append("CSRFToken", c_save),
            b.append("passlama", $('#passlamax').val()),
            b.append("inputPs", strMD5);
        $.ajax({
            url: base_url + "front/Profilsiswa/ajaxcekpass",
            type: "POST",
            data: b,
            contentType: !1,
            cache: !1,
            processData: !1,
            dataType: "JSON",
            success: function(c) {
                c.status ? ($('.passlama').css('border', '1px solid red'), $('.alertCheck').hide().show('slow').html('<strong>Pass Lama Anda Salah... !!</strong>').delay(3000).hide('slow')) : ($('.passlama').css('border', '1px solid #7E92B2'));
            }
        })
    }), $('.ulangi').focusout(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var strMD5 = $().crypt({
            method: "md5",
            source: $('.ulangi').val()
        });
        var b = new FormData();
            b.append("CSRFToken", c_save),
            b.append("inputPs", strMD5);
        if ($('.ulangi').val() == $('.passbaru').val() && $('.ulangi').val() != "" && $('.passbaru').val() != "") {
        $('.ulangi').css('border', '1px solid #7E92B2');
        $.ajax({
            url: base_url + "front/Profilsiswa/ajaxupdatepass",
            type: "POST",
            data: b,
            contentType: !1,
            cache: !1,
            processData: !1,
            dataType: "JSON",
            success: function(c) {
                c.status && ($('#passEdit').hide('slow'), $('.closeeditpass').hide('slow'), $('.btnEditpassword').show('slow'), $('.alertCheck').hide().show('slow').html('<strong>Password Berhasil Dirubah...</strong>').delay(3000).hide('slow'));
            }
        })
        } else {
            $('.ulangi').css('border', '1px solid red'), $('.alertCheck').hide().show('slow').html('<strong>Password Tidak Sama...</strong>').delay(3000).hide('slow')
        }
    }), $("#fileInput").change(function() {
        var c_save = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var fd = new FormData();
        var files = $(this)[0].files;
        if(files.length > 0 ){
           fd.append("CSRFToken", c_save);
           fd.append('file', files[0]);
           fd.append('filepotodulu', $('#potolama').val());
        $.ajax({
            url: base_url + "front/Profilsiswa/ajaxuploadpoto",
            type: 'POST',
            data: fd,
            contentType: false,
            processData: false,
            success: function(res){
                res.status && location.reload();            }
        });
        }
    })
});