/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});
tinymce.init({
    selector: "textarea",theme: "modern",width: '100%',height: 200,
    menubar:false,
    statusbar: false,
    plugins: [
         "eqneditor advlist autolink link image lists charmap print preview hr anchor pagebreak",
         "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking",
         "table contextmenu directionality emoticons paste textcolor responsivefilemanager code"
   ],
   setup: function (editor) {
        editor.on('change', function () {
            editor.save();
        });
    },
   toolbar1: "bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist | subscript superscript | eqneditor responsivefilemanager image | preview code",
   image_advtab: true ,
   relative_urls:false,
   external_filemanager_path:base_url+"assets/filemanager/",
   filemanager_title:"Responsive Filemanager" ,
   external_plugins: { "filemanager" : base_url+"assets/filemanager/plugin.min.js"}
 });

function csrf_table() {
    var c_table = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    return c_table;
}

var table;
var tabledatasoal;
$(document).ready(function() {
    $('.form_datetime').datetimepicker({
        format: 'dd-mm-yyyy hh:ii',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1
    }), $("#tgl_awl").on('changeDate', function(selected) {
        var startDate = new Date(selected.date.valueOf());
        $("#tgl_ahr").datetimepicker('setStartDate', startDate);
        if($("#tgl_awl").val() > $("#tgl_ahr").val()){
          $("#tgl_ahr").val($("#tgl_awl").val());
        }
    });
    table = $('#table_data').DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        paging:!1,
        ordering:!1,
        info: !1,
        filter: !1,
        retrieve: !1,
        order: [],
        ajax: {
            url: base_url + "dash/Banksoal/ajaxlist",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table()
                })
            }
        },
 
        columnDefs: [{
            targets: [0, 5, 6, 7, 8, 9, 10],
            orderable: !1
        }, {
            className: "text-center",
            targets: [0,4,5,6,7,8,9,10]
        }, {
            className: "text-nowrap",
            targets: [0, 1]
        }],
    });
    showsoalTable();
    showsoalTable_all();

    $("#ModeSoal").validationEngine();
    $(".suc").hide();
    $("#btnSave").click(function () {
    var url;
    var save_method = $('#savemethod').val();
    var validni = $("#ModeSoal").validationEngine('validate');
    checkCheckbox();
    if(save_method == "") {
    url = base_url +'dash/Banksoal/ajaxadd';
    } else {
    url = base_url +'dash/Banksoal/ajaxupdate';  
    }
    var r = $("#errorCheckbox").text();

    if (1 == validni && "" == r) {
    $('.loader').show();
    $('#btnSave').text('saving...');
    $('#btnSave').attr('disabled',true);
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    var dt = new FormData($("#ModeSoal")[0]);
        dt.append("CSRFToken", xData);

    $.ajax({
        url : url,
        type: "POST",
        data: dt,
        contentType: !1,
        cache: !1,
        processData: !1,
        dataType: "JSON",
        success: function(data)
        {
            if(data.status) {
                reload_table();
                $('.loader').hide();
                if(data.idmode != "") {
                $(".modenya").hide();
                $(".datamodenya").hide();
                $(".datasoalnya").show();
                if(save_method == "") {
                $("#save_mode").val(data.idmode);
                $("#jml_soal").val($('[name="jml_soal"]').val());
                get_nosoal(data.idmode);
                } else {
                show_detail_soal(data.idmode)
                }
                } else {
                $(".modenya").show();
                $(".datamodenya").show();
                $(".datasoalnya").hide();
                $('.hideJml').show();
                $('.jmlHide').text('Jml Soal*');
                $('#dataIds_plh').val('');
                $(".suc").hide().text(data.ket+' Soal Berhasil Disimpan').show('slow').delay(3000).hide('slow');
                }
                $('#ModeSoal')[0].reset();
        }
            $('#btnSave').text('Save Soal');
            $('#btnSave').attr('disabled',false);
        },
        
    });

    }
    else {
        $("#ModeSoal").validationEngine();
    }
});

    $("#InputSoal").validationEngine();
    $(".suc").hide();
    $("#btnSaveSoal").click(function () {
    
    var url;
    var save_methodsoal = $('#save_methodsoal').val();
    var validni = $("#InputSoal").validationEngine('validate');

    if(save_methodsoal == "") {
    url = base_url +'dash/Banksoal/ajax_add_soal';
    } else {
    url = base_url +'dash/Banksoal/ajax_saveedit_soal';
    }

    if (validni == true) {
    $('.loader').show();
    $('#btnSaveSoal').text('saving...');
    $('#btnSaveSoal').attr('disabled',true);
    tinyMCE.triggerSave();
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    var dt = new FormData($("#InputSoal")[0]);
        dt.append("CSRFToken", xData);
    $.ajax({
        url : url,
        type: "POST",
        data: dt,
        contentType: !1,
        cache: !1,
        processData: !1,
        dataType: "JSON",
        success: function(data)
        {
            if(data.status) {
                reload_table();
                $('.loader').hide();
                $('#InputSoal')[0].reset();
                $(".modenya").hide();
                $(".datamodenya").hide();
                $(".datasoalnya").show();
                if(save_methodsoal == "") {
                $("#save_mode").val(data.idmode);
                get_nosoal(data.idmode);
                } else {
                show_detail_soal(data.idmode);
                $("#nx").text('0');
                }
                $("html, body").animate({ scrollTop: 0 }, "slow");
                $(".suc").hide().text('Data Soal Berhasil Disimpan').show('slow').delay(3000).hide('slow');
        }
            $('#btnSaveSoal').text('Save Soal');
            $('#btnSaveSoal').attr('disabled',false);
 
        },
        
    });

    }
    else {
        $("#InputSoal").validationEngine();
    }
    
});

$.getJSON( base_url +'dash/Banksoal/ajax_get_guru', function(data) {
    $("#nipguru").empty();
    $.each(data, function(idx, obj) {
    $("#nipguru").append($("<option></option>").val(obj.nip).html(obj.nama));
    }), $("#nipguru").selectpicker("refresh");
});

$("#nipguru").on('change', function() {
    if ($("#nipguru option:selected" ).val() != "") {
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    $.post(base_url + "dash/Banksoal/awalKelas", {CSRFToken: xData, nip: $("#nipguru option:selected" ).val()}).done(function(e) {
        $('.liakKls').show(), $(".is_datakelas").empty(), $(".is_datakelas").html('<div col-md-12><b>'+e.ids+'</b></div>'),
        $.each(e.kls, function(e, a) {
        $(".is_datakelas").append('<input type="checkbox" value="'+a+'" name="kelas[]" id="_'+a+'_" class="ckelasc"><label for="_'+a+'_"><span><span></span></span>'+a+'</label>');
        });
        $(".ckelasc").change(function() {
            var countChk = $("#ModeSoal input[name='kelas[]']:checked").length;
            if(countChk > 0) {
                $('#errorCheckbox').html('');
            } else {
                $('#errorCheckbox').html('<div class="A1formError parentFormRegs formError" style="opacity: 0.87; pointer-events: none; position: absolute; top: 1rem; left: 50px; margin-top: -30px;"><div class="formErrorContent">* Pilih salah satu kelas</div></div>');
            }
        });
    });
    } else {
        $('.liakKls').hide(), $(".is_datakelas").empty(), $('#errorCheckbox').html('')
    }
});

$('#Acopy').on('change', function(){ 
    if(this.checked) {
        $('.hideJml').hide();
        $('.jmlHide').text('');
    $('#modalCopySoal').modal('show');
    reload_tabledatasoal_all();
    var data = [];
    $('#dataIds_plh').val('');
    $('#table_all_soal tbody').on('change', 'input.editor-active', function () {
    var checkboxes = $('input.editor-active:checked');
    var len = checkboxes.length;
    for (var i=0; i<len; i++) {
        data[i] = checkboxes[i].id;
    }
    $('#dataIds_plh').val(data);
    });
    } else {
        $('.hideJml').show();
        $('.jmlHide').text('Jml Soal*');
        $('#dataIds_plh').val('');
        reload_tabledatasoal_all();
    }
});

$("#DetailSoal").validationEngine();
$('#DetailSoal').on('keyup keypress', function(e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) { 
    e.preventDefault();
    return false;
  }
});

$(".tableMode tbody").on("change", "input[type=checkbox]", function() {
        var xDatax = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        var a = $(this).val(),
            e = $(this).attr("name"),
            t = ($(this).attr("id"), $(this).parent().prev().attr("class"), {
                CSRFToken: xDatax,
                idni: e,
                valni: a
            });
        $.ajax({
            type: "POST",
            url: base_url + "dash/Banksoal/ajaxonoff",
            data: t,
            cache: !1,
            dataType: "JSON",
            success: function(a) {
                reload_table()
            }
        })
    })

}); 

function reload_table()
{
    table.ajax.reload(null,false); 
}

function reload_tabledatasoal()
{
    $('#table_datasoal').DataTable().clear().destroy();
    showsoalTable();
    tabledatasoal.ajax.reload(null,false); 
}

function reload_tabledatasoal_all()
{
    $('#table_all_soal').DataTable().clear().destroy();
    showsoalTable_all();
    tabledatasoal.ajax.reload(null,false); 
}

function showsoalTable_all() {
tabledatasoal = $('#table_all_soal').DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },

        ajax: {
            url: base_url + "dash/Banksoal/list_datasoal_all",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table(),
                    notidmode: $('#detail_modesoal').val()
                })
            }
        },

        columnDefs: [{
            targets: [0],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 1, 2, 3, 4, 5, 6]
        }, {
            width: "5%",
            targets: [8]
        }, {
            className: "text-center",
            targets: [0, 1, 2, 3, 4, 5, 6, 8]
        }, {
            className: "text-nowrap",
            targets: [0, 1, 2, 3]
        }],
        fixedColumns: true
    });
}

function showsoalTable() {
tabledatasoal = $('#table_datasoal').DataTable({
        responsive: !0,
        processing: !0,
        serverSide: !0,
        info: !1,
        order: [],
        language: {
            paginate: {
                next: ">>",
                previous: "<<"
            }
        },

        ajax: {
            url: base_url + "dash/Banksoal/list_datasoal",
            type: "POST",
            data: function(a) {
                return $.extend({}, a, {
                    CSRFToken: csrf_table(),
                    modeid: $('#detail_modesoal').val(),
                })
            }
        },

        columnDefs: [{
            targets: [0, 9, 10],
            orderable: !1
        }, {
            width: "3%",
            targets: [0, 1, 2, 3, 4, 5, 6, 9, 10]
        }, {
            width: "5%",
            targets: [8]
        }, {
            className: "text-center",
            targets: [0, 1, 2, 3, 4, 5, 6, 8, 9, 10]
        }, {
            className: "text-nowrap",
            targets: [0, 1, 2, 3]
        }],
        fixedColumns: true
    });
}

function get_nosoal(idmode)
{
    var jml_butir = $("#jml_soal").val();
    var jdno_x = parseInt($("#nx").text()) + 1;
    if(jdno_x > jml_butir) {
    show_detail_soal(idmode);
    $("#nx").text('0');
    } else {
    $("#nx").text(jdno_x);
    }
}

function show_detail_soal(idmode)
{
    $(".modenya").hide();
    $(".datamodenya").hide();
    $(".datasoalnya").hide();
    $(".datasoalnya").hide();
    $(".dataisisoal").show();
    $("#detail_modesoal").val(idmode);
    reload_tabledatasoal();
    $.getJSON( base_url +'dash/Banksoal/ajax_mode_show', {id: idmode}).done(function(data) {
    $(".gurux").text(data.nama);
    $(".judulx").text(data.judul_test);
    $(".durasix").text(data.durasi + " Menit");
    if (data.kls_dipilih != "") {
        var jdkls = '';
        var kls = data.kls_dipilih.split(',');
        $.each(kls, function(i, d) {
            jdkls += '<span class="label-kls">'+d+'</span>'
        });
    $(".sekolahx").html(data.nama_sekolah + '<br>'+jdkls);
    }
    $(".tampilx1").text(data.tgl_tampil_awal);
    $(".tampilx2").text(data.tgl_tampil_akhir);
    $(".jmlx").text(data.jml_soal + " Butir");
    });
}

function show_tambah_soal()
{
    var validni = $("#DetailSoal").validationEngine('validate');
    $('#save_methodsoal').val('');
    if (validni == true && $('#idetail_JmlTambah').val() > 0) {
    $("#save_mode").val($('#detail_modesoal').val());
    $("#jml_soal").val($('#idetail_JmlTambah').val());
    get_nosoal($('#detail_modesoal').val());
    $(".modenya").hide();
    $(".datamodenya").hide();
    $(".datasoalnya").hide();
    $(".datasoalnya").show();
    $(".dataisisoal").hide();
    $('#DetailSoal')[0].reset();
    }
}

function show_tambahcopy_soal() {
  var ids = $('#detail_modesoal').val();
  $('#modalCopySoal').modal('show');
  $('#closeModal').hide();
  $('#saveModal').show();
    reload_tabledatasoal_all();
    var data = [];
    $('#tabahCopy_ids').val('');
    $('#table_all_soal tbody').on('change', 'input.editor-active', function () {
    var checkboxes = $('input.editor-active:checked');
    var len = checkboxes.length;
    for (var i=0; i<len; i++) {
        data[i] = checkboxes[i].id;
    }
    $('#tabahCopy_ids').val(data);
    });

    $('#saveModal').on('click', function() {
    $('#modalCopySoal').modal('hide');
    $('.loader').show();
    var idsoalCopy = $('#tabahCopy_ids').val();
    var jml_c = (idsoalCopy.match(/\,/g) || []).length + 1;
    $.getJSON( base_url +'dash/Banksoal/ajaxaddcopy', {ids: ids, is_i: idsoalCopy}).done(function(e) {
        if(e.status){
        reload_tabledatasoal();
        $('#tabahCopy_ids').val('');
        var kurang_c = jml_c - e.ket;
        if(e.ket == jml_c && e.ket > 0) {
        $(".suc").hide().text(e.ket+' Soal Berhasil Ditambahkan').show('slow').delay(3000).hide('slow');
        }
        else if(e.ket == jml_c && e.ket == 0) {
        $(".suc").hide().text(jml_c+' Soal Yg Dicopy Sudah Ada...').show('slow').delay(3000).hide('slow');
        } else {
        $(".suc").hide().text(e.ket+' Berhasil, '+kurang_c+' Soal Yg Dicopy Sudah Ada...').show('slow').delay(3000).hide('slow');    
        }
        $('.loader').hide();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        }
    });
    })
}

function show_edit_modesoal()
{
    $(".modenya").show();
    $(".datamodenya").hide();
    $(".datasoalnya").hide();
    $(".datasoalnya").hide();
    $(".dataisisoal").hide();
    edit_mode_get($('#detail_modesoal').val())
}

function edit_mode_get(idmode)
{
    $('#savemethod').val(idmode);
    $.getJSON( base_url +'dash/Banksoal/ajax_edit', {id: idmode}).done(function(jns) {
    $("#nipguru").val(jns.nip).trigger('change');
    if (jns.kls_dipilih != "") {
        setTimeout(function(){ 
        var kls = jns.kls_dipilih.split(',');
        $.each(kls, function(i, d) {
            $('.ckelasc#_'+d+'_').prop("checked", true);
        });
    },300);
    }
    $('[name="durasi"]').val(jns.durasi);
    $('[name="tgl_awal"]').val(jns.tgl_tampil_awal);
    $('[name="tgl_akhir"]').val(jns.tgl_tampil_akhir);
    $('[name="judul"]').val(jns.judul_test);
    $('.hideEdit').hide();
    });
}

function edit_soal(id,idmode)
{
    $(".modenya").hide();
    $(".datamodenya").hide();
    $(".datasoalnya").hide();
    $(".datasoalnya").show();
    $(".dataisisoal").hide();
    $('#save_methodsoal').val(id);
    $('#save_mode').val(idmode);
    $("#nx").text('');
    $.getJSON( base_url +'dash/Banksoal/ajax_edit_soal', {id: id}).done(function(data) {
        $('[name="soal"]').html(data.soal);
        tinyMCE.get('soal').setContent(data.soal, {format : 'raw'});
        $('[name="kunci_jawaban"]').val(data.kunci_jawaban).attr("selected", "selected");
        $('[name="kunci_alasan"]').val(data.kunci_alasan).attr("selected", "selected");
        $('#my_jawaban').html(data.jawaban);
        tinyMCE.get('my_jawaban').setContent(data.jawaban);
        $('#my_alasan').html(data.alasan);
        tinyMCE.get('my_alasan').setContent(data.alasan);
        $('[name="kode"]').val(data.kode);
        var b, bi1, bi2, bi3, a, c;
        if(data.b == 0) {b = '0.0'} else {b = data.b}
        if(data.bi1 == 0) {bi1 = '0.0'} else {bi1 = data.bi1}
        if(data.bi2 == 0) {bi2 = '0.0'} else {bi2 = data.bi2}
        if(data.bi3 == 0) {bi3 = '0.0'} else {bi3 = data.bi3}
        if(data.a == 0) {a = '0.0'} else {a = data.a}
        if(data.c == 0) {c = '0.0'} else {c = data.c}
        $('[name="b"]').val(b);
        $('[name="bi1"]').val(bi1);
        $('[name="bi2"]').val(bi2);
        $('[name="bi3"]').val(bi3);
        $('[name="a"]').val(a);
        $('[name="c"]').val(c);
    });
}

function delete_mode(id)
{
    if(confirm('Yakin akan menghapus soal ini?'))
    {
        $('.loader').show();
        var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        $.ajax({
            url : base_url +'dash/Banksoal/ajax_delete',
            type: "POST",
            data: {CSRFToken: xData, id: id},
            dataType: "JSON",
            success: function(data)
            {
                $('#ModeSoal')[0].reset();
                $('#savemethod').val('');
                $("#nipguru").selectpicker("refresh");
                $('.liakKls').hide();
                $('#dataIds_plh').val('');
                reload_table();
                reload_tabledatasoal();
                reload_tabledatasoal_all();
                $('.loader').hide();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                $(".hpsmode").hide().show('slow').delay(3000).hide('slow');
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });
 
    }
}

function checkCheckbox() {
    var countChk = $("#ModeSoal input[name='kelas[]']:checked").length;
    if(countChk == 0) {
        $('#errorCheckbox').html('<div class="A1formError parentFormRegs formError" style="opacity: 0.87; pointer-events: none; position: absolute; top: 1rem; left: 50px; margin-top: -30px;"><div class="formErrorContent">* Pilih salah satu kelas</div></div>');
    }
    else {
        $('#errorCheckbox').html('')
    }
}

function delete_soal(id)
{
    if(confirm('Yakin akan menghapus soal ini?'))
    {
        $('.loader').show();
        var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
        $.ajax({
            url : base_url +'dash/Banksoal/ajax_delete_soal',
            type: "POST",
            data: {CSRFToken: xData, id: id},
            dataType: "JSON",
            success: function(data)
            {
                reload_table();
                reload_tabledatasoal();
                reload_tabledatasoal_all();
                $('.loader').hide();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                $(".hps").hide().show('slow').delay(3000).hide('slow');
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });
 
    }
}