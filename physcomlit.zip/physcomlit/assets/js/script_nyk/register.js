/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(url, data) {
        var theResponse = null;
        $.ajax({
            url: url,
            type: 'GET',
            dataType: "JSON",
            async: false,
            success: function(respText) {
                theResponse = respText;
            }
        });
        return theResponse;
    }
});

function check() {
    var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
    $.post(base_url + "login/Register/validusername", {
        CSRFToken: xData,
        username: $("#nis").val()
    }, function(a) {
        1 == a ? $("#errorcheck").html("<div style='opacity: 0.87; position: absolute; top: 0px; left: 197px; margin-top: -34px;' class='usernameformError parentFormOwner formError ajaxed'><div class='formErrorContent'>* Username sudah dipakai</div><div class='formErrorArrow'><div class='line10'>\x3c!-- --\x3e</div><div class='line9'>\x3c!-- --\x3e</div><div class='line8'>\x3c!-- --\x3e</div><div class='line7'>\x3c!-- --\x3e</div><div class='line6'>\x3c!-- --\x3e</div><div class='line5'>\x3c!-- --\x3e</div><div class='line4'>\x3c!-- --\x3e</div><div class='line3'>\x3c!-- --\x3e</div><div class='line2'>\x3c!-- --\x3e</div><div class='line1'>\x3c!-- --\x3e</div></div></div>") : $("#errorcheck").html("")
    })
}

function showsekolah() {
    $.getJSON(base_url + "login/Register/ajaxsekolah", function(e) {
        $("#nama_sekolah").empty(), 
        $("#nama_sekolah").append($("<option></option>").val("").html("--Pilih Sekolah--"));
        $.each(e, function(e, a) {
            $("#nama_sekolah").append($("<option></option>").val(a.idsekolah).html(a.nama_sekolah));
        })
    });
}
 
$(document).ready(function() {
    showsekolah();
    $("#Registeruser").validationEngine(), $("#btnSave").click(function() {
        check();
        var t = $("#Registeruser").validationEngine("validate");
        var s = $("#errorcheck").text();
        if (1 == t && "" == s) {
            var strMD5 = $().crypt({
                method: "md5",
                source: $('#passW').val()
            });
            var n = new FormData($("#Registeruser")[0]);
            var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
            n.append("CSRFToken", xData), n.append("pass", strMD5), n.append("passx", $('#passW').val()), $.ajax({
                url: base_url + "login/Register/ajaxadd",
                type: "POST",
                data: n,
                contentType: !1,
                cache: !1,
                processData: !1,
                dataType: "JSON",
                success: function(a) {
                    1 == a.status && ($("#Registeruser")[0].reset(), $('.showRegis').hide('slow'), $('.showLog').show('slow'), $('.infoReggster').hide().html('<strong>Registrasi Success!</strong><br>Data Registrasi Anda Berhasil Disimpan').show('slow').delay(3000).hide('slow'));
                }
            })
        } else $("#Registeruser").validationEngine()
    }), $('#Registeruser').keypress(function(d) {
        13 == d.which && $('#btnSave').click()
    }), $("#nama_sekolah").on('change', function() {
        $.getJSON(base_url + "login/Register/ajaxKelas", {skl: $("#nama_sekolah option:selected" ).val()}).done(function(e) {
        $("#kelas").empty(), $("#kelas").append($("<option></option>").val("").html("--Pilih Kelas--"));
        $.each(e, function(e, a) {
            $("#kelas").append($("<option></option>").val(a.kls).html(a.kls));
        })
        });
    }), $(".Pesankontak").validationEngine(), $(".btnKrmpesan").click(function() {
        var t = $(".Pesankontak").validationEngine("validate");
        if (1 == t) {
            var nx = new FormData($(".Pesankontak")[0]);
            var xData = $.xResponse(base_url + 'CSRF', {issession: 1,selector: true});
            nx.append("CSRFToken", xData), $.ajax({
                url: base_url + "login/Register/ajaxaddpesan",
                type: "POST",
                data: nx,
                contentType: !1,
                cache: !1,
                processData: !1,
                dataType: "JSON",
                success: function(a) {
                    1 == a.status && ($(".Pesankontak")[0].reset(), $('.showRegis').hide('slow'), $('.showLog').show('slow'), $('.infoReggster').hide().html('<strong>Pesan Success Terkirim!</strong><br>Silahkan tunggu balasan email dari kami...<br>TERIMAKASIH...').show('slow').delay(3000).hide('slow'));
                }
            })
        } else $(".Pesankontak").validationEngine()
    })
});