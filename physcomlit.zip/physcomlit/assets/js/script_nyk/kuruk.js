/*!
 * Mardiant_Shulah (smardiant@gmail.com)
 *
 * Copyright 2021 Shulah
 */
"use strict";
$.extend({
    xResponse: function(d) {
        var f = null;
        return $.ajax({
            url: d,
            type: 'GET',
            dataType: 'JSON',
            async: !1,
            success: function(g) {
                f = g
            }
        }), f
    }
}), $(document).ready(function() {
    $('#Loginuser').validationEngine(), $('.loginAdmin').click(function() {
        var strMD5 = $().crypt({
                method: "md5",
                source: $('#password').val()
            });
        var d = $.xResponse(base_url + 'CSRF', {
                issession: 1,
                selector: !0
            }),
            e = $('#Loginuser').validationEngine('validate'),
            f = $('#Loginuser').serializeArray();
        f.push({
            name: 'CSRFToken',
            value: d
        }), f.push({
            name: 'userid',
            value: $('#user').val()
        }), f.push({
            name: 'psswid',
            value: strMD5
        }), !0 == e ? ($('.loading').show(), $.ajax({
            url: base_url + 'login',
            type: 'POST',
            data: f,
            dataType: 'JSON',
            success: function(g) {
                if (g.status) {
                    $('#Loginuser')[0].reset();
                    if (g.ambil == 'Administrator' || g.ambil == 'Guru') {
                        window.location.href = base_url + 'Beranda';
                    } else {
                        window.location.href = base_url + 'Test';
                    }
                } else {
                    $('.loading').hide(), $('.error').hide().show('slow').delay(4e3).hide('slow'), $('#Loginuser')[0].reset();
                }
            }
        })) : $('#Loginuser').validationEngine()
    }), $('#Loginuser').keypress(function(d) {
        13 == d.which && $('.loginAdmin').click()
    })
});