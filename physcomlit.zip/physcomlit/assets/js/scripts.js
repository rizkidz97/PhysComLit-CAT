/*!
* Start Bootstrap - Scrolling Nav v5.0.3 (https://startbootstrap.com/template/scrolling-nav)
* Copyright 2013-2021 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-scrolling-nav/blob/master/LICENSE)
*/
//
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

  // $('.loop').owlCarousel({
  //     center: true,
  //     items:2,
  //     loop:false,
  //     nav: false,
  //     margin:10,
  //     responsive:{
  //         992:{
  //             items:4
  //         }
  //     }
  // });
    $('.clickLogin').on('click', function() {
          $('.showLog').show('slow'), $('.showRegis').hide('slow');
    })

    $('.clickRegister').on('click', function() {
          $('.showRegis').show('slow'), $('.showLog').hide('slow')
    })

    $(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll < 306) {
        $("#nol").addClass("active");
        history.pushState({}, null, window.location.pathname);
    } else {
        $("#nol").removeClass("active");
    }
    if (scroll >= 306 && scroll < 1122) {
        $("#sai").addClass("active");
        history.pushState({}, null, "#fitur");
    } else {
        $("#sai").removeClass("active");
    }
    if (scroll >= 1122 && scroll < 2040) {
        $("#khua").addClass("active");
        history.pushState({}, null, "#profil");
    } else {
        $("#khua").removeClass("active");
    }
    if (scroll >= 2040 && scroll < 3060) {
        $("#telu").addClass("active");
        history.pushState({}, null, "#kurikulum");
    } else {
        $("#telu").removeClass("active");
    }
    if (scroll >= 3060 && scroll < 3060 + $("#portfolio").height()) {
        $("#epak").addClass("active");
        history.pushState({}, null, "#portfolio");
    } else {
        $("#epak").removeClass("active");
    }
    if (scroll >= 3060 + $("#portfolio").height() && scroll < 4182) {
        $("#lima").addClass("active");
        history.pushState({}, null, "#kontak");
    } else {
        $("#lima").removeClass("active");
    }
    if (scroll >= 4182) {
        $("#siwa").addClass("active");
        if($("#login").is(":visible"))
        history.pushState({}, null, "#login");
    } else {
        $("#siwa").removeClass("active");
    }
    });
    // Activate Bootstrap scrollspy on the main nav element
    // const mainNav = document.body.querySelector('#mainNav');
    // if (mainNav) {
    //     new bootstrap.ScrollSpy(document.body, {
    //         target: '#mainNav',
    //         offset: 150,
    //     });
    // };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});
