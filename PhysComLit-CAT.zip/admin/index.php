﻿<!-- <?php 
session_start();
//cek apakah admin telah login bila ya maka redirect ke halaman admin
if (isset($_SESSION['logged'])) //{
 //   header('location:admin.php');
    exit
//}
?>
-->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Form Login</title>
        <link href="framework/bootstrap/css/bootstrap2.css" rel="stylesheet">
        <!--	// simbol ../ berarti masuk ke direktori parrent satu tingkat. (menuju ke direktori ca_tes) -->
    </head>

    <body>
        <!-- Navbar -->
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <!--
                    <a class="brand" href="index.php"><b>CAT</b></a>
                    <ul class="nav">
                        <!--Menuju Halaman Peserta-->
                    <!--
                        <li><a href="../index.php">Halaman Peserta</a></li>
                    </ul>
                    -->
                </div>
            </div>
        </div>
<br>
<br>
        <!-- Login Form -->
        <div class="container">
            <div class="row">
                <div class="span12">
                    <div style="margin-top:5em;">
                        <div class="row">
                            <div class="column">
                                <div class="span4">
                                    <center>
                                        <form class="well" id="login" action="login.php" method="post">
                                            <div class="login-form">
                                                <h2>Login Admin</h2>
                                                <fieldset>
                                                    <div>
                                                        <input type="text" placeholder="Username" id="username" name="username">
                                                    </div>
                                                    <div>
                                                        <input style="width:145px;" type="password" placeholder="Password" id="password" name="password">
                                                        <button class=" btn btn-primary" type="submit" style="margin-bottom:9px;">Login</button>
                                                    </div>
                                                    <br>
                                                    <p>Login sebagai Peserta?</p>
                                                    <a href="../peserta/index.php" class="btn btn-primary pull-center">Login Peserta</a>
                                                    <br>
                                                    <br>
                                                    <p>Versi S2.013.022</p>
                                                    <P>&copy 2021</P>
                                                </fieldset>
                                            </div>
                                        </form>
                                    </center>
                                </div>                    

                                <div class="span8">
                                <div class="hero-unit">
                                    <div style="margin-top:0em;">
                                    <center>
                                        <img src="uny.png" alt="" style="width:165px;height:139px;">
                                    </center>
                                    </div>
                                    <center>
                                        <h2>Selamat Datang</h2>
                                        <p><i>Physics Computational and Science Literacy</i></p>
                                        <p><i>Computerized Adaptive Test</i></p>
                                    </center>
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>


        <?php
        if (!empty($_GET['error'])) {
            if ($_GET['error'] == 'salah') {
                echo '<br />';
                echo '<center>Username atau Password salah</center>';
                echo '</div>';
            }
        }
        ?>

    <!-- </div> --> 
    <script src="../framework/jquery.js"></script>
    <script src="../framework/bootstrap/js/bootstrap.js"></script>
    </body>
</html>
