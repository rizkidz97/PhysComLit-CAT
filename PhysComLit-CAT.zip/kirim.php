<?php
if($_POST['kirim']){
	$admin = 'r.zakwandi@gmail.com'; //ganti email dg email admin (email penerima pesan)
	
	$name	= htmlentities($_POST['name']);
	$surname	= htmlentities($_POST['surname']);
	$email	= htmlentities($_POST['email']);
	$subject	= htmlentities($_POST['subject']);
	$massage	= htmlentities($_POST['massage']);
	
	$pengirim	= 'Dari: '.$nama.' <'.$email.'>';
	
	if(mail($admin, $judul, $pesan, $pengirim)){
		echo 'SUCCESS: Pesan anda berhasil di kirim. <a href="index.php">Kembali</a>';
	}else{
		echo 'ERROR: Pesan anda gagal di kirim silahkan coba lagi. <a href="index.php">Kembali</a>';
	}
}else{
	header("Location: index.php");
}
?>