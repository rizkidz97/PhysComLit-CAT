﻿<!--
<?php
session_start();
//cek apakah peserta tes telah login bila ya maka redirect ke halaman peserta
if (isset($_SESSION['log_peserta'])) {
//    header('location:peserta.php');
    exit;
}
?>
-->


<!DOCTYPE html>
<html>
</html>
<html lang="en"> 
    <head>
        <meta charset="utf-8">
        <title>Form Login</title>
        <link href="framework/bootstrap/css/bootstrap2.css" rel="stylesheet">
    </head>
    
    <body class="sidebar-mini layout-fixed" style="height: auto;">
        <div class="wrapper">
        </div>
    </body>


    <body>

        <!-- Navbar -->
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="column">
            <div class="navbar-inner">
                <div class="container">
                    <br>

                    <!--
                    <a class="brand" href="index.php"><b>HOME</b></a>
                    
                    <!--
                    <ul class="nav">
                        <!--Menuju Halaman Admin-->
                        <!--
                            <a href="admin/index.php" class="btn btn-primary pull-right">Login Admin</a>
                    </ul>
                    <div class="span8">
                    </div>-->
                    
                </div>
            </div>
        </div>
        </div>
<br>
<br>
        <!-- Login Form -->
        <div class="container">
            <div class="row">
                <div class="span12">
                    <div style="margin-top:5em;">
                        <div class="row">
                            <div class="column">
                                <div class="span4">
                                    <center>
                                        <form class="well" id="login" action="login.php" method="post">
                                            <div class="login-form">
                                                <h2>Login Peserta</h2>
                                                <fieldset>
                                                    <div>
                                                        <input type="text" placeholder="Nomor Peserta" name="nomor">
                                                    </div>
                                                    <div>
                                                    <input style="width:145px;" type="password" placeholder="Password" id="password" name="password">
                                                    <button class=" btn btn-primary" type="submit" style="margin-bottom:9px;">Login</button>
                                                    </div>
                                                    <br>
                                                    <p>Login sebagai admin?</p>
                                                    <a href="../admin/index.php" class="btn btn-primary pull-center">Login Admin</a>
                                                    <br>
                                                    <br>
                                                    <p>Versi S2.013.022</p>
                                                    <P>&copy 2021</P>
                                                </fieldset>
                                            </div>
                                        </form>
                                    </center>
                                </div>
                            <div class="span8">
                                <div class="hero-unit">
                                    <div style="margin-top:0em;">
                                    <center>
                                        <img src="uny.png" alt="" style="width:165px;height:139px;">
                                    </center>
                                    </div>
                                    <center>
                                        <h2>Selamat Datang</h2>
                                        <p>Physics Computational and Science Literacy</p>
                                        <p>Computerized Adaptive Test</p>
                                    </center>
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
        <?php
        if (!empty($_GET['error'])) {
            if ($_GET['error'] == 'salah') {
                echo '<br />';
                echo '<center>Nomor Peserta atau Password salah</center>';
                echo '</div>';
            }
        }
        ?>
    </div>
    <script src="framework/jquery.js"></script>
    <script src="framework/bootstrap/js/bootstrap.js"></script>
</body>
</html>
